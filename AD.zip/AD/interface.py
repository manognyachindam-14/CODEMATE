import tkinter as tk
from tkinter import messagebox, scrolledtext

def run_code():
    code = code_input.get("1.0", tk.END)
    
    try:
        exec(code)
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Python Code Runner")

code_input = scrolledtext.ScrolledText(root, height=20, width=60)
code_input.pack()

run_button = tk.Button(root, text="Run", command=run_code)
run_button.pack()

root.mainloop()
