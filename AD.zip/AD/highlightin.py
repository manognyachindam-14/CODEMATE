def highlight_code(code):
    keywords = ['if', 'else', 'while', 'for', 'def', 'class'] # Example list of keywords

    highlighted_code = ""
    current_word = ""
    in_string = False

    for char in code:
        if char in [' ', '\t', '\n']:
            if in_string:
                current_word += char
            else:
                if current_word in keywords:
                    current_word = f"\033[1m{current_word}\033[0m" # Add bold formatting
                highlighted_code += current_word + char
                current_word = ""
        elif char == '"' or char == "'":
            if in_string:
                current_word += char
                highlighted_code += f"\033[32m{current_word}\033[0m" # Add green color for strings
                current_word = ""
                in_string = False
            else:
                if current_word:
                    if current_word in keywords:
                        current_word = f"\033[1m{current_word}\033[0m" # Add bold formatting for keywords
                    highlighted_code += current_word
                current_word = char
                in_string = True
        else:
            current_word += char

    return highlighted_code


# Example usage
# Python 3 program for recursive binary search.
# Modifications needed for the older Python 2 are found in comments.
 
# Returns index of x in arr if present, else -1
def binary_search(arr, low, high, x):
 
    # Check base case
    if high >= low:
 
        mid = (high + low) // 2
 
        # If element is present at the middle itself
        if arr[mid] == x:
            return mid
 
        # If element is smaller than mid, then it can only
        # be present in left subarray
        elif arr[mid] > x:
            return binary_search(arr, low, mid - 1, x)
 
        # Else the element can only be present in right subarray
        else:
            return binary_search(arr, mid + 1, high, x)
 
    else:
        # Element is not present in the array
        return -1
 
# Test array
arr = [ 2, 3, 4, 10, 40 ]
x = 10
 
# Function call
result = binary_search(arr, 0, len(arr)-1, x)
 
if result != -1:
    print("Element is present at index", str(result))
else:
    print("Element is not present in array")

highlighted_code = highlight_code(code)
print(highlighted_code)
